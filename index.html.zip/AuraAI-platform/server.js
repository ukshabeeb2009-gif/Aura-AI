import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import bcrypt from "bcryptjs";
import OpenAI from "openai";
import pg from "pg";
import { randomUUID, randomBytes, timingSafeEqual } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === "production";
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: production ? { rejectUnauthorized: false } : undefined,
  max: 10
});
const PgSession = connectPgSimple(session);
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

if (!process.env.DATABASE_URL) {
  console.error("Missing DATABASE_URL. Configure PostgreSQL in .env before starting AuraAI.");
  process.exit(1);
}
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters. Generate a long random value in .env.");
  process.exit(1);
}
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: production ? [] : null
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  name: "auraai.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: production,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const apiLimiter = rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false });
app.use("/api", apiLimiter);

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in to continue." });
  next();
}
function ensureCsrf(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const sent = req.get("x-csrf-token") || "";
  const expected = req.session.csrfToken || "";
  const a = Buffer.from(sent), b = Buffer.from(expected);
  if (!sent || a.length !== b.length || !timingSafeEqual(a, b)) {
    return res.status(403).json({ error: "Security token expired. Refresh the page and try again." });
  }
  next();
}
app.use("/api", ensureCsrf);

async function initDatabase() {
  const schema = await readFile(path.join(__dirname, "db", "schema.sql"), "utf8");
  await pool.query(schema);
}
app.get("/api/csrf", (req, res) => {
  req.session.csrfToken ||= randomBytes(32).toString("hex");
  res.json({ csrfToken: req.session.csrfToken });
});

app.post("/api/signup", authLimiter, asyncRoute(async (req, res) => {
  const { email, password, displayName } = req.body || {};
  const cleanEmail = typeof email === "string" ? email.trim().toLowerCase() : "";
  const cleanName = typeof displayName === "string" ? displayName.trim().slice(0, 40) : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return res.status(400).json({ error: "Enter a valid email address." });
  if (typeof password !== "string" || password.length < 10 || password.length > 72) return res.status(400).json({ error: "Password must be 10–72 characters." });
  if (cleanName.length < 2) return res.status(400).json({ error: "Enter a display name (at least 2 characters)." });

  const passwordHash = await bcrypt.hash(password, 12);
  try {
    const result = await pool.query(
      "INSERT INTO users(email,password_hash,display_name) VALUES($1,$2,$3) RETURNING id,email,display_name",
      [cleanEmail, passwordHash, cleanName]
    );
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.userId = result.rows[0].id;
    req.session.csrfToken = randomBytes(32).toString("hex");
    res.status(201).json({ user: { id: result.rows[0].id, email: result.rows[0].email, displayName: result.rows[0].display_name }, csrfToken: req.session.csrfToken });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "An account with this email already exists." });
    throw e;
  }
}));

app.post("/api/login", authLimiter, asyncRoute(async (req, res) => {
  const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  const result = await pool.query("SELECT id,email,display_name,password_hash FROM users WHERE email=$1", [email]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
  req.session.userId = user.id;
  req.session.csrfToken = randomBytes(32).toString("hex");
  res.json({ user: { id: user.id, email: user.email, displayName: user.display_name }, csrfToken: req.session.csrfToken });
}));

app.get("/api/me", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query("SELECT id,email,display_name,created_at FROM users WHERE id=$1", [req.session.userId]);
  if (!result.rowCount) return res.status(401).json({ error: "Account not found." });
  const count = await pool.query("SELECT COUNT(*)::int AS chats FROM chats WHERE user_id=$1", [req.session.userId]);
  res.json({ user: { id: result.rows[0].id, email: result.rows[0].email, displayName: result.rows[0].display_name, joinedAt: result.rows[0].created_at }, stats: { chats: count.rows[0].chats } });
}));

app.post("/api/logout", requireAuth, asyncRoute(async (req, res) => {
  await new Promise((resolve, reject) => req.session.destroy(err => err ? reject(err) : resolve()));
  res.clearCookie("auraai.sid", { httpOnly: true, sameSite: "lax", secure: production });
  res.json({ ok: true });
}));

app.get("/api/chats", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT id,title,created_at,updated_at FROM chats WHERE user_id=$1 ORDER BY updated_at DESC LIMIT 100",
    [req.session.userId]
  );
  res.json({ chats: result.rows });
}));

app.post("/api/chats", requireAuth, asyncRoute(async (req, res) => {
  const id = randomUUID();
  const title = typeof req.body?.title === "string" ? req.body.title.trim().slice(0, 80) || "New conversation" : "New conversation";
  const result = await pool.query(
    "INSERT INTO chats(id,user_id,title) VALUES($1,$2,$3) RETURNING id,title,created_at,updated_at",
    [id, req.session.userId, title]
  );
  res.status(201).json({ chat: result.rows[0] });
}));

app.get("/api/chats/:id/messages", requireAuth, asyncRoute(async (req, res) => {
  const owned = await pool.query("SELECT id FROM chats WHERE id=$1 AND user_id=$2", [req.params.id, req.session.userId]);
  if (!owned.rowCount) return res.status(404).json({ error: "Chat not found." });
  const result = await pool.query("SELECT id,role,content,created_at FROM messages WHERE chat_id=$1 ORDER BY created_at ASC", [req.params.id]);
  res.json({ messages: result.rows });
}));

app.delete("/api/chats/:id", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query("DELETE FROM chats WHERE id=$1 AND user_id=$2 RETURNING id", [req.params.id, req.session.userId]);
  if (!result.rowCount) return res.status(404).json({ error: "Chat not found." });
  res.json({ ok: true });
}));

app.post("/api/chats/:id/message", requireAuth, asyncRoute(async (req, res) => {
  if (!openai) return res.status(503).json({ error: "AI is not configured. Add OPENAI_API_KEY to the server environment." });
  const chatId = req.params.id;
  const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
  if (!content || content.length > 6000) return res.status(400).json({ error: "Message must be between 1 and 6000 characters." });

  const owned = await pool.query("SELECT id,title FROM chats WHERE id=$1 AND user_id=$2", [chatId, req.session.userId]);
  if (!owned.rowCount) return res.status(404).json({ error: "Chat not found." });

  const previous = await pool.query(
    "SELECT role,content FROM messages WHERE chat_id=$1 ORDER BY created_at DESC LIMIT 12",
    [chatId]
  );
  const history = previous.rows.reverse().map(m => ({ role: m.role, content: m.content }));
  await pool.query("INSERT INTO messages(chat_id,role,content) VALUES($1,'user',$2)", [chatId, content]);
  if (owned.rows[0].title === "New conversation") {
    await pool.query("UPDATE chats SET title=$1,updated_at=NOW() WHERE id=$2 AND user_id=$3", [content.slice(0, 55), chatId, req.session.userId]);
  } else {
    await pool.query("UPDATE chats SET updated_at=NOW() WHERE id=$1 AND user_id=$2", [chatId, req.session.userId]);
  }

  res.status(200);
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.flushHeaders?.();

  let answer = "";
  try {
    const stream = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: "You are AuraAI, a helpful and accurate assistant. Reply in the language the user uses. If they write Malayalam, use clear Malayalam. Be age-appropriate and safe. Be honest about uncertainty.",
      input: [...history, { role: "user", content }],
      stream: true
    });
    for await (const event of stream) {
      if (event.type === "response.output_text.delta") {
        answer += event.delta;
        res.write(event.delta);
      }
      if (event.type === "response.failed" || event.type === "error") throw new Error("AI response failed.");
    }
    if (answer) {
      await pool.query("INSERT INTO messages(chat_id,role,content) VALUES($1,'assistant',$2)", [chatId, answer]);
      await pool.query("UPDATE chats SET updated_at=NOW() WHERE id=$1 AND user_id=$2", [chatId, req.session.userId]);
    }
    res.end();
  } catch (error) {
    console.error("Streaming request failed:", error.message);
    if (!res.headersSent) res.status(500);
    res.write("\n\n[Sorry, AuraAI could not finish this response. Please try again.]");
    res.end();
  }
}));

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, _req, res, _next) => {
  console.error("Server error:", err.message);
  if (res.headersSent) return;
  res.status(500).json({ error: "Something went wrong. Please try again." });
});

await initDatabase();
app.listen(port, () => console.log(`AuraAI Platform running on port ${port}`));
