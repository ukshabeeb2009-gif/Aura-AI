const $ = id => document.getElementById(id);
let csrfToken = "";
let user = null;
let chats = [];
let activeChatId = null;
let busy = false;
let authMode = "login";
let latestAnswer = "";

async function api(url, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body) headers["Content-Type"] = "application/json";
  if (!["GET", "HEAD"].includes(options.method || "GET") && csrfToken) headers["x-csrf-token"] = csrfToken;
  const response = await fetch(url, { credentials: "same-origin", ...options, headers });
  const data = response.headers.get("content-type")?.includes("application/json") ? await response.json() : null;
  if (!response.ok) throw new Error(data?.error || "Request failed.");
  return data;
}
async function refreshCsrf() { const d = await api("/api/csrf"); csrfToken = d.csrfToken; }
function toast(message) { const el=$("toast"); el.textContent=message; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2600); }
function showAuth(mode="login") {
  authMode=mode; $("authScreen").classList.remove("hidden"); $("appShell").classList.add("hidden");
  const signup=mode==="signup"; $("authTitle").textContent=signup?"Create your account.":"Welcome back.";
  $("authSubtitle").textContent=signup?"Start your own private AI workspace.":"Sign in to continue your conversations.";
  $("nameField").classList.toggle("hidden",!signup); $("displayName").required=signup;
  $("authSubmit").textContent=signup?"Create account":"Sign in";
  $("switchText").textContent=signup?"Already have an account?":"New to AuraAI?";
  $("switchAuth").textContent=signup?"Sign in":"Create account"; $("authError").textContent="";
  $("password").autocomplete=signup?"new-password":"current-password";
}
function enterApp(profile) {
  user=profile; $("authScreen").classList.add("hidden"); $("appShell").classList.remove("hidden");
  $("profileName").textContent=user.displayName; $("avatar").textContent=(user.displayName||"A")[0].toUpperCase();
  $("topProfile").textContent=user.displayName.split(" ")[0]; loadChats(); showView("chat");
}
$("switchAuth").onclick=()=>showAuth(authMode==="login"?"signup":"login");
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault(); $("authSubmit").disabled=true; $("authError").textContent="";
  try {
    const body={email:$("email").value,password:$("password").value};
    if(authMode==="signup") body.displayName=$("displayName").value;
    const result=await api(authMode==="signup"?"/api/signup":"/api/login",{method:"POST",body:JSON.stringify(body)});
    csrfToken=result.csrfToken; enterApp(result.user);
  } catch(err){$("authError").textContent=err.message;}
  finally{$("authSubmit").disabled=false;}
});
async function loadChats(){
  try{const d=await api("/api/chats");chats=d.chats;renderHistory();if(activeChatId&&!chats.some(c=>c.id===activeChatId))activeChatId=null;if(!activeChatId&&chats.length)activeChatId=chats[0].id;await loadActiveChat();}
  catch(e){toast(e.message);}
}
function renderHistory(){
  const list=$("historyList");list.replaceChildren();
  chats.forEach(chat=>{const b=document.createElement("button");b.className="history-item"+(chat.id===activeChatId?" active":"");b.textContent=chat.title;b.title=chat.title;b.onclick=async()=>{activeChatId=chat.id;await loadActiveChat();renderHistory();showView("chat");$("sidebar").classList.remove("open");};list.append(b);});
}
async function loadActiveChat(){
  const box=$("messages");box.replaceChildren();latestAnswer="";
  if(!activeChatId){$("welcome").hidden=false;return;}
  const d=await api(`/api/chats/${activeChatId}/messages`);
  $("welcome").hidden=d.messages.length>0;
  d.messages.forEach(m=>renderMessage(m.role,m.content,false));scrollMessages();
}
function renderMessage(role,content,scroll=true){
  $("welcome").hidden=true;
  const row=document.createElement("div");row.className="message "+role;
  if(role==="assistant"){const badge=document.createElement("div");badge.className="message-badge";badge.textContent="✦";row.append(badge);}
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content;row.append(bubble);
  if(role==="assistant"){latestAnswer=content;const copy=document.createElement("button");copy.className="copy-button";copy.textContent="Copy answer";copy.onclick=()=>navigator.clipboard.writeText(content).then(()=>toast("Copied"));bubble.append(copy);}
  $("messages").append(row);if(scroll)scrollMessages();return bubble;
}
function scrollMessages(){$("chatArea").scrollTop=$("chatArea").scrollHeight;}
async function newChat(){
  const d=await api("/api/chats",{method:"POST",body:JSON.stringify({})});chats.unshift(d.chat);activeChatId=d.chat.id;renderHistory();$("messages").replaceChildren();$("welcome").hidden=false;showView("chat");$("sidebar").classList.remove("open");$("promptInput").focus();
}
$("newChat").onclick=()=>newChat().catch(e=>toast(e.message));
async function sendMessage(text){
  if(busy||!text.trim())return;
  busy=true;$("sendButton").disabled=true;
  try{
    if(!activeChatId){const d=await api("/api/chats",{method:"POST",body:JSON.stringify({})});activeChatId=d.chat.id;chats.unshift(d.chat);}
    renderMessage("user",text.trim());$("promptInput").value="";
    const bubble=renderMessage("assistant","");bubble.textContent="AuraAI is thinking…";bubble.parentElement.classList.add("streaming");
    const response=await fetch(`/api/chats/${activeChatId}/message`,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","x-csrf-token":csrfToken},body:JSON.stringify({content:text.trim()})});
    if(!response.ok){const d=await response.json().catch(()=>({}));throw new Error(d.error||"AI request failed.");}
    bubble.textContent="";const reader=response.body.getReader();const decoder=new TextDecoder();let answer="";
    while(true){const {done,value}=await reader.read();if(done)break;answer+=decoder.decode(value,{stream:true});bubble.textContent=answer;scrollMessages();}
    bubble.parentElement.classList.remove("streaming");latestAnswer=answer;
    const copy=document.createElement("button");copy.className="copy-button";copy.textContent="Copy answer";copy.onclick=()=>navigator.clipboard.writeText(answer).then(()=>toast("Copied"));bubble.append(copy);
    await loadChats();
  }catch(e){toast(e.message);if(!activeChatId)$("welcome").hidden=false;}
  finally{busy=false;$("sendButton").disabled=false;$("promptInput").focus();}
}
$("chatForm").addEventListener("submit",e=>{e.preventDefault();sendMessage($("promptInput").value);});
$("promptInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("chatForm").requestSubmit();}});
$("promptInput").addEventListener("input",()=>{const x=$("promptInput");x.style.height="auto";x.style.height=Math.min(x.scrollHeight,150)+"px";});
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>{$("promptInput").value=b.dataset.prompt;$("promptInput").focus();});
function showView(view){$("chatView").classList.toggle("hidden",view!=="chat");$("dashboardView").classList.toggle("hidden",view!=="dashboard");document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>{showView(b.dataset.view);$("sidebar").classList.remove("open");if(b.dataset.view==="dashboard")loadDashboard();});
$("topProfile").onclick=()=>{showView("dashboard");loadDashboard();};
async function loadDashboard(){
  try{const d=await api("/api/me");$("chatCount").textContent=d.stats.chats;$("dashName").textContent=d.user.displayName;$("dashEmail").textContent=d.user.email;$("joinedDate").textContent="Member since "+new Date(d.user.joinedAt).toLocaleDateString();}
  catch(e){toast(e.message);}
}
$("themeToggle").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("auraai-dark",document.body.classList.contains("dark"));};
if(localStorage.getItem("auraai-dark")==="true")document.body.classList.add("dark");
$("menuToggle").onclick=()=>$("sidebar").classList.toggle("open");
$("logoutButton").onclick=async()=>{try{await api("/api/logout",{method:"POST",body:JSON.stringify({})});}catch{}activeChatId=null;chats=[];user=null;await refreshCsrf();showAuth("login");};
$("voiceButton").onclick=()=>{
  const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SpeechRecognition){toast("Voice input is not supported in this browser. Try recent Chrome or Edge.");return;}
  const recognition=new SpeechRecognition();recognition.lang="ml-IN";recognition.interimResults=false;recognition.onresult=e=>{$("promptInput").value=e.results[0][0].transcript;$("promptInput").focus();};recognition.onerror=()=>toast("Microphone permission or speech recognition is unavailable.");recognition.start();
};
$("speakButton").onclick=()=>{
  if(!latestAnswer){toast("There is no answer to read yet.");return;}
  if(!("speechSynthesis" in window)){toast("Speech output is not supported in this browser.");return;}
  speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(latestAnswer);utterance.lang="ml-IN";speechSynthesis.speak(utterance);
};
(async()=>{
  try{
    await refreshCsrf();
    const me=await api("/api/me");enterApp(me.user);
  }catch{showAuth("login");}
})();
