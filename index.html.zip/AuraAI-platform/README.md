# AuraAI Platform 2.0

AuraAI is upgraded from the uploaded starter project into a full-stack starter platform using HTML, CSS, vanilla JavaScript, Node.js/Express, PostgreSQL, secure sessions and the OpenAI Responses API.

## Included

- Email signup and login with bcrypt password hashing.
- PostgreSQL users, chats and messages tables.
- Private chat history: every chat read/write/delete query checks the signed-in user's ownership.
- Streaming AI text responses in the chat interface.
- Voice input through browser speech recognition and spoken answers through browser text-to-speech.
- Premium-style dashboard with profile and conversation count.
- Responsive design, dark mode, chat sidebar and sign out.
- Session cookies are HttpOnly and SameSite=Lax; HTTPS is required in production.
- CSRF token validation for state-changing API requests, login/signup rate limiting, general API rate limiting, Helmet security headers and server-side API key.

## Important feature scope

"Voice conversation" in this version uses browser speech-to-text to fill the chat composer and browser text-to-speech to read an AI answer. It is not a continuous, low-latency, full-duplex OpenAI Realtime voice session. Speech recognition availability and Malayalam accuracy depend on browser, device, locale and microphone permissions.

The dashboard is a premium-style interface only. No subscription, payment processing or paid-tier entitlement is enabled.

The uploaded ZIP contained the original chat app only; it did not contain Google search or image generation endpoints. This upgrade focuses on the six requested platform features and does not claim those older optional features were present.

## Requirements

- Node.js 20+
- A PostgreSQL database
- An OpenAI API key with access to the model configured below
- HTTPS for public production deployment

If you are under 18, ask a parent/guardian to manage API/hosting accounts, billing, database credentials and spending limits. API and hosting use may cost money.

## Local setup (Windows PowerShell)

1. Install Node.js 20 or newer.
2. Create a PostgreSQL database using a provider or local PostgreSQL installation.
3. Extract this folder and open PowerShell inside `AuraAI-platform`.
4. Install dependencies:

   ```powershell
   npm install
   ```

5. Copy `.env.example` to `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

6. Edit `.env` and set:
   - `DATABASE_URL` to your PostgreSQL connection string.
   - `SESSION_SECRET` to a random secret with at least 32 characters.
   - `OPENAI_API_KEY` to the private server API key.
   - `OPENAI_MODEL` to a model available to your API account.
   - Keep `NODE_ENV=development` for local use.

7. Start the app:

   ```powershell
   npm start
   ```

8. Open `http://localhost:3000`.

The server creates the application tables from `db/schema.sql` on startup. The PostgreSQL session store creates its session table automatically.

## Public deployment checklist

Deploy the Node app to a Node-compatible host and provision a managed PostgreSQL database. The exact dashboard labels vary by provider.

1. Push this project to a private source repository (never include `.env`).
2. Create a Node web service and attach/provision PostgreSQL.
3. Add environment variables in the host dashboard:
   - `DATABASE_URL`
   - `SESSION_SECRET` (generate a new random secret, at least 32 characters)
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL`
   - `NODE_ENV=production`
   - `TRUST_PROXY=true` only if the hosting provider terminates HTTPS at a trusted proxy and forwards proxy headers.
4. Configure the host to run `npm install` and `npm start`.
5. Enable HTTPS and test signup, login, chat streaming, account isolation and logout.
6. Keep database backups enabled and review provider access controls and spending limits.

Do not publish until the environment variables are configured and the app has been tested. Do not share API keys, database passwords or session secrets in chat, screenshots or public repositories.

## Security and production notes

This is a starter implementation, not a security audit or a guarantee of production readiness. Before a public launch, have a qualified adult/developer review the deployment, database TLS settings, backups, logs, account recovery, email verification, abuse prevention, privacy notice, retention policy, accessibility and applicable legal requirements. Consider adding email verification and password reset before allowing public registration.

The app currently stores chat text in PostgreSQL. Anyone with database administrator access can access that data, so secure the database account and backups. The user-facing app enforces per-user chat ownership checks.

## Project structure

```text
AuraAI-platform/
  db/schema.sql
  public/index.html
  public/style.css
  public/app.js
  .env.example
  .gitignore
  package.json
  server.js
  README.md
```
